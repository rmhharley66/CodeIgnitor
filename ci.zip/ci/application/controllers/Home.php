<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index() {
        //Get the data    
       $data['main'] = 'general/home-view';  
       $this->load->view('main' , $data);
        
	}
}
