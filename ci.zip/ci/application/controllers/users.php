<?php 

    class Users extends CI_Controller {

        //create
        public function insert() {
            $username = 'twix';
            $password = 'secret';
            
            $this->user_model->create_users([
                'username' => $username,
                'password' => $password
            ]);
        }
        
        //read
        public function show($user_id){
            $data['results'] = $this->user_model->get_users($user_id);
            $this->load->view('user_view',$data);
        }
        
        
       //update 
        public function update() {
            $id = 9;
            
            $username = 'almondJoy';
            $password = '1234';
            
            $this->user_model->update_users([
                'username' => $username,
                'password' => $password
            ] , $id);          
        }
        
        //delete
        public function delete() {
            $id = 7;
            $this->user_model->delete_users($id);
        }
        
        //login
        
        public function login() {


                $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
                

                if($this->form_validation->run() == FALSE) {
                    $data = array(
                        'errors' => validation_errors()
                    );

                    $this->session->set_flashdata($data);
                    redirect();
                    
                } else {

                $username = $this->input->post('username');
                $password = $this->input->post('password');
                $user_id = $this->user_model->login_user($username , $password);
                   
                    if($user_id) {
                         
                        $user_data = array(

                            'user_id' => $user_id,
                            'username' => $username,
                            'logged_in' => true
                    );
                        
                    $this->session->set_userdata($user_data);
                    $this->session->set_flashdata('login_success', 'You are now logged in');

                    redirect();

                    } else {

                         
                        $this->session->set_flashdata('login_failed', 'Sorry You are not logged in');
                       redirect();

                    }

                }
        }
        
        

    }

 ?>




