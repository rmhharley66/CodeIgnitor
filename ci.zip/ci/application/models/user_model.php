<?php 

    class User_model extends CI_model {
        //Read data from database
        public function get_users($user_id) {
            //how you get info from database
            $this->db->where([
                'id' => $user_id
            ]);
            //$this->db->where('id', $user_id);
            
            $query = $this->db->get('users');
            return $query->result();
        }
        
        //insert data into database
        public function create_users($data) {
            $this->db->insert('users' , $data);
        }
        
        //update data in the database
        public function update_users($data , $id) {
            $this->db->where(['id' => $id]);
            $this->db->update('users' , $data);
        }
        
        //delet data in the database
        public function delete_users($id) {
            
            $this->db->where(['id' => $id]);
            $this->db->delete('users');          
        }
        
        
        public function login_user($username , $password){
            $this->db->where('username' , $username);
            $this->db->where('password' , $password);  
            
            $result = $this->db->get('users');
            if($result->num_rows() == 1){
                return $result->row(0)->id;
            }else {
                return false;
            }
        }

    }

 ?>


