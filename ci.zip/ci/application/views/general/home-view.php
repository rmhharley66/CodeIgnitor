
<section id="brand_center">
    </section>
    <main id="site-container" class="container-fluid">
        <div id="main-interaction-container" class="container-fluid">
            <div id="main-interaction">
                <span></span>
                <div class="col-md-4">
                    <div class="content-container">
                        <h5>Get A Quote</h5>
                        <div></div>
                        <div></div>
                        <div><p><a>Continue a saved quote</a></p></div>
    4               </div>
                </div>
                <div class="col-md-4">
                    <div class="content-container">
                        <h5>Contact Us</h5>
                        <div>Talk to a local agent</div>
                        <div><input type="text" /></div>
                        <div><p><a>More search options</a></p></div>
                    </div>
                </div>
                <div class="col-md-4">
                      <div class="content-container">
                        <h5>Manage Claims</h5>
                        <div>Start a claim</div>
                        <div>
                            <select>
                            </select>
                        </div>
                        <div>
                            <p><a>Check the status of a claim</a></p>
                            <p><a>Go to the Claims Center</a></p>
                        </div>
                    </div>              
                </div>
            </div>
        </div>
        <div id="customer-interaction">
            <div class="col-md-9">
                <h5>What We Offer</h5>
                <ul id="customer-interaction-nav">
                    <li>Auto</li>
                    <li>Home</li>
                    <li>Renters</li>
                    <li>Condo</li>
                    <li>Motorcycle</li>
                    <li>Life</li>
                    <li>Banking</li>
                    <li>More</li>
                </ul>
                <div id="customer-interaction-content">
                
                    <div class="box"></div>
                </div>

            </div>
            <div class="col-md-3">
                <h5>You Might Like</h5>
            </div>      
        </div>
    </main>

