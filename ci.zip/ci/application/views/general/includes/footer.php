
    <footer class="footer">
        <nav id="footer">
            <ul id="first-footer" class="footer-nav col-md-4">
                <li class="h2">Insurance Coverage</li>
                <li><a href="https://www.statefarm.com/insurance/auto" class="block">Car Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/home-and-property/homeowners" class="block">Home Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/home-and-property/renters" class="block">Renters Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/home-and-property/condo-unit-owners" class="block">Condo Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/motorcycles" class="block">Motorcycle Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/health/supplemental-insurance" class="block">Supplemental Health Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/sport-leisure-vehicles/boats" class="block">Boat Insurance</a></li>

                <li><a href="https://www.statefarm.com/insurance/health/medicare-supplemental" class="block">Medicare Supplement Insurance</a></li>
                <li><a href="https://www.statefarm.com/small-business-solutions/insurance" class="block">Business Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/life" class="block">Life Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/health" class="block">Health Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/disability" class="block">Disability Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance/long-term-care" class="block">Long-Term Care Insurance</a></li>
                <li><a href="https://www.statefarm.com/insurance" class="block">More Insurance Options</a></li>
			</ul>

             <ul class="footer-nav col-md-2">
                 <li class="h2">State Farm Bank</li>
                <li><a href="https://www.statefarm.com/finances/banking/checking-accounts" class="block">Checking Accounts</a></li>
                <li><a href="https://www.statefarm.com/finances/banking/savings-accounts" class="block">Saving Accounts</a></li>
                <li><a href="https://www.statefarm.com/finances/banking/cds" class="block">Fixed Rate CDs</a></li>
                <li><a href="https://www.statefarm.com/finances/banking/credit-cards" class="block">Credit Cards</a></li>
                <li><a href="https://www.statefarm.com/finances/banking/loans/vehicles" class="block">Car Loans</a></li>
                <li><a href="https://www.statefarm.com/finances/banking/loans/home-mortgage" class="block">Home Mortgages</a></li>
                <li><a href="https://online2.statefarm.com/bank/rates/index.xhtml" class="block">Bank Rates</a></li>
                 
            </ul>
            
            <ul class="footer-nav col-md-2">
                <li class="h2">Mutual Funds</li>
                <li><a href="https://www.statefarm.com/finances/mutual-funds/types-of-accounts/mutual-funds-ira" class="block">Mutual Funds IRA</a></li>
                <li><a href="https://www.statefarm.com/finances/mutual-funds/resources/rollovers-transfers" class="block">IRA Rollovers and Transfers</a></li>
                <li><a href="https://www.statefarm.com/finances/education-savings-plans" class="block">Education Savings Plans</a></li>
                <li><a href="https://www.statefarm.com/finances/mutual-funds/fund-selection-tool" class="block">Choosing Mutual Funds</a></li>
                <li><a href="https://www.statefarm.com/finances/mutual-funds/investment-resources/state-farm-investment-team" class="block">Fund Management</a></li>
                <li><a href="https://www.statefarm.com/finances/mutual-funds" class="block">All About Mutual Funds</a></li>          
            </ul>
            <ul class="footer-nav col-md-2">
                <li class="h2">Customer Care</li>
                <li><a href="https://www.statefarm.com/customer-care" class="block">Help Center</a></li>
                <li><a href="https://www.statefarm.com/customer-care/learning-resource-center" class="block">Learning Resource Center</a></li>
                <li><a href="https://www.statefarm.com/customer-care/online-payments" class="block">Make a Payment</a></li>
                <li><a href="https://www.statefarm.com/customer-care/manage-your-accounts" class="block">Manage Your Accounts</a></li>
                <li><a href="https://www.statefarm.com/claims/find-a-select-service-repair-facility" class="block">Find a Repair Facility</a></li>
                <li><a href="https://www.statefarm.com/customer-care/faqs/insurance" class="block">Request Insurance Card</a></li>
                <li><a href="https://www.statefarm.com/customer-care/download-mobile-apps" class="block">Download Mobile</a></li>          
            </ul>
            
            
            <ul class="footer-nav col-md-2">
                <li class="h2">About State Farm</li>
                <li><a href="https://www.statefarm.com/about-us/company-overview/company-profile/state-farm-story" class="block">Our Story</a></li>
                <li><a href="https://www.statefarm.com/about-us/company-overview/our-agents" class="block">State Farm Agents</a></li>
                <li><a href="https://www.statefarm.com/about-us/community" class="block">Community Involvement</a></li>
                <li><a href="https://www.statefarm.com/about-us/community/safety-awareness/disaster-response" class="block">Disaster Response</a></li>
                <li><a href="https://www.statefarm.com/about-us/newsroom" class="block">Newsroom</a></li>
                <li><a href="https://www.statefarm.com/careers" class="block">Careers</a></li>
                <li><a href="http://neighborhoodsessions.statefarm.com/" class="block">Neighborhood Sessions<sup>®</sup></a></li>
                <li><a href="https://www.statefarm.com/about-us" class="block">More About State Farm</a></li>        
            </ul>
        
        </nav>
        
        <div class="clearfix"></div>
        <div class="footer-notes">
            <p>*State Farm received the highest numerical score among life insurance providers in the proprietary J.D. Power 2014 U.S. Household Insurance and Bundling Study<sup>SM</sup>. Study based on 23,171 total responses measuring 21 providers and measures opinions of consumers with their life insurance provider. Proprietary study results are based on experiences and perceptions of consumers surveyed June-July 2014. Your experiences may vary. Visit <a href="http://www.jdpower.com/press-releases/2015-us-household-insurance-study%E2%80%94individual-life" title="External Link: J.D. Power" target="_blank" class="null">jdpower.com</a>.</p>

            <p><font size="1"><sup>1</sup> Discounts vary by state.</font></p>

            <p>State Farm Bank®, Bloomington, Illinois, is a Member FDIC and Equal Housing Lender. NMLS ID 139716. The other products offered by affiliate companies of State Farm Bank <strong>are not FDIC insured, not a State Farm Bank obligation or guaranteed by State Farm Bank, and subject to investment risk, including possible loss of principal invested.</strong> Contact State Farm Bank toll-free at 877-SF4-BANK (877-734-2265).</p>
            <p>Life Insurance and annuities are issued by State Farm Life Insurance Company. (Not Licensed in MA, NY, and WI) State Farm Life and Accident Assurance Company (Licensed in New York and Wisconsin) Home Office, Bloomington, Illinois</p>
        </div>
    </div>
        <p class="clearfix">Copyright 2015, Rico Developer Test</p>
    </footer>
