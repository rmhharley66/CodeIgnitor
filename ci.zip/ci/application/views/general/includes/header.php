<div id="top-nav" class="container-fluid">

    
</div>
<header class="container-fluid">
    <nav id="header">
        <span id="logo" class="col-md-2"><img src="<?php echo base_url(); ?>assets/images/logo.png" /></span>
        <span>
            Insurance
            <ul>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
                <li>Link</li>
            </ul>
        </span>
        <span>Finance</span>
        <span>Claims</span>
        <span>Customer Care</span>
        <span>Login</span>
        
  <!-- Customer Login form +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->      
        <?php if($this->session->userdata('logged_in')): ?>
            <h2>Logout</h2>
            <?php echo form_open('users/logout'); ?>
                <p>
                    <?php if($this->session->userdata('username')): ?>
                        <?php echo "You are logged in as " . $this->session->userdata('username'); ?>
                    <?php endif; ?>
                </p>
                <?php 
                    $data = array(
                        'class'=> 'btn btn-primary',
                        'name'=> 'submit',
                        'value' => 'Logout'
                    );
                 ?>
                 <?php echo form_submit($data); ?>
             <?php echo form_close(); ?>

        <?php else: ?>

            <?php if($this->session->flashdata('errors')): ?>
                <?php echo '<b id="login-errors">' .  $this->session->flashdata('errors') . ' </b>'; ?>
            <?php endif; ?>

            <?php $attributes = array('id' =>"login_form" , 'class' => 'form_horizontal'); ?>
            <?php echo form_open('../../users/login' , $attributes); ?>
            <aside class="form_group">
                <?php echo form_label('Username'); ?>
                <?php 

                    $data = array(
                        'class' => 'form-control',
                        'name' => 'username',
                        'placeholder' => 'Enter Username'
                    );

                ?>
                <?php echo form_input($data); ?>
             </aside>

            <aside class="form_group">
                <?php echo form_label('Password'); ?>
                 <?php 

                    $data = array(
                        'class' => 'form-control',
                        'name' => 'password',
                        'placeholder' => 'Enter Password'
                    );

                ?>
                <?php echo form_password($data); ?>
            </aside>

            <aside class="form_group">
                 <?php 

                    $data = array(
                        'class' => 'btn btn-primary',
                        'name' => 'submit',
                        'value' => 'Login'
                    );

                ?>
                <?php echo form_submit($data); ?>
            </aside>
            <?php echo form_close(); ?>
        
        <?php endif; ?>
  <!-- Customer Login form +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->          

    </nav>
</header>


